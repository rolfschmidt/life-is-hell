function StateManager() {}

StateManager.prototype.preload = function(scene) {
}

StateManager.prototype.create = function(scene) {
    this.done = false;
}

StateManager.prototype.update = function(scene) {
}
